export const data = {
    "inputGroup": {
        "id": "input1",
        "type": "password",
        "validation": "all",
        "maxlength": 16
    }
}