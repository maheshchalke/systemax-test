const data = {
    "inputGroup": {
        "id": "inputBox1",
        "type": "password",
        "isValidation": true,
        "checkPasswordStrength": true,
        "maxlength": 16,
        "isShowPassword": true,
        "helpTexr": "Help!!",
        "isAutofocus": true,
        "placeHolderText": "New Password"
    }
}

$(document).ready(function() {
   
    loadHtmlElement();
});

const passwordAttr = {
    type: "password",
    name:"password",
    autofocus: true,
    autocomplete:"off",
    placeholder: "Password",
    maxlength: "10"
}

function getDiv(){
    var elemDiv = document.createElement('div');
    return elemDiv;
}

function getSpan(){
    var elemSpan = document.createElement('span');
    return elemSpan;
}

function getInput(){
    var elemInput = document.createElement('input');
    return elemInput;
}

function getLabel(){
    var elemLabel = document.createElement('label');
    return elemLabel;
}

function getInputBox(id) {
    var inputBox = getDiv();
    $(inputBox).attr("id", id);
    
    var helpDiv= getDiv();
    $(helpDiv).attr("class", "help");
    
    var fieldLabel = getLabel();
    $(fieldLabel).attr({"for": "new-pwd", "class": "move-up"});
    $(fieldLabel).append('<span>Password:</span>');

    var passwordField = getInput();
    $(passwordField).attr({...passwordAttr});

    inputBox.append(helpDiv);
    inputBox.append(fieldLabel);
    inputBox.append(passwordField);
    return inputBox;
}


function loadHtmlElement() {
    var inputGroup = data.inputGroup;
    var inpotBox = getInputBox(data.inputGroup.id);
    $(inpotBox).attr("class", "input-grp new-pwd-grp");
    $('body').append(inpotBox);
}




/* I can write more common function in the case of multiple elements */