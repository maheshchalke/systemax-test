$(document).ready(function() {
    openDropDown();
    selectItem();
});

function hideShowDropDown(element, sItem){
    var selectedItem = element.find(".selected-item");
    var dropDownList = element.find(".dowpdown-list");
    var selectedItemName = selectedItem.attr("data-SelectedItem");
    if($(element).hasClass('active')) {
        $(element).removeClass('active')
        if(sItem) {
            selectedItem.attr('data-SelectedItem', sItem)
        }
    } else {
        $(element).addClass('active');
        dropDownList.find("li").removeClass('selected');
        dropDownList.find("li[data-item='"+ selectedItemName +"']").addClass('selected');
    }
}

function openDropDown() {
    var nameDropDown = $("#name-dropDown");
    var selectedItem = nameDropDown.find(".selected-item");
    var dropDownList = nameDropDown.find(".dowpdown-list");
    selectedItem.click(function() {
        hideShowDropDown(nameDropDown);
    });
}

function selectItem(){
    var nameDropDown = $("#name-dropDown");
    var selectedItemSpan = nameDropDown.find(".selected-item").find('span');
    var dropDownList = nameDropDown.find(".dowpdown-list");
    var listItems = dropDownList.find("li");
    listItems.each(function(){
        $(this).click(function(){
            selectedItemSpan.text($(this).text());
            hideShowDropDown(nameDropDown, $(this).attr('data-item'));
        })
    })
}

/* I can write more common function in the case of multiple elements */